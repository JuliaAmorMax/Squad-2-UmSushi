// Card.tsx - conteúdo exemplo
