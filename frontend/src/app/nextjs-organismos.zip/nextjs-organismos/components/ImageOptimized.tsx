// ImageOptimized.tsx - conteúdo exemplo
