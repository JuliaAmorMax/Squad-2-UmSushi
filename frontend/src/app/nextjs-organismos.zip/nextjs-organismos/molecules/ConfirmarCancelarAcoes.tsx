// ConfirmarCancelarAcoes.tsx - conteúdo exemplo
