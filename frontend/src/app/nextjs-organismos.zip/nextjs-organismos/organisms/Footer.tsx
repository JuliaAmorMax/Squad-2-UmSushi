// Footer.tsx - conteúdo exemplo
