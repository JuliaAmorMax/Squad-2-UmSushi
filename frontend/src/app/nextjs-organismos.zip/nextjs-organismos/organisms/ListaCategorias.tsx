// ListaCategorias.tsx - conteúdo exemplo
